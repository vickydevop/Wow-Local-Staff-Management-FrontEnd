# Angular

- Angular Docs - <https://angular.io>

- Angular Material Docs - <https://material.angular.io>

- Material Extensions (open source library supported by community developer) - <https://ng-matero.github.io/extensions/components/categories>

- Tailwind CSS - <https://tailwindcss.com>

- Moment JS - <https://momentjs.com>