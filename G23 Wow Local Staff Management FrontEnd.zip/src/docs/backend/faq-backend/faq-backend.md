<div align="center">
Backend - Frequently Asked Questions 
</div>

1. ### Updating Nest JS CLI Globally

```bash
     npm uninstall -g @nestjs/cli
     npm install -g @nestjs/cli
```
---

### Note

- dev_dependencies are modules which are only required during development,

- while dependencies are modules which are also required at runtime.
